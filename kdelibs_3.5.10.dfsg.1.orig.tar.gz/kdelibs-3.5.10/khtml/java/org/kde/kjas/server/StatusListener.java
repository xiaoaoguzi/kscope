package org.kde.kjas.server;

public interface StatusListener {
    public void showStatus(String message);
}