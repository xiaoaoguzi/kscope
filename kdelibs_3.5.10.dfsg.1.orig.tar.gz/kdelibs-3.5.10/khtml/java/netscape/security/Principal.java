package netscape.security;

public class Principal {
}