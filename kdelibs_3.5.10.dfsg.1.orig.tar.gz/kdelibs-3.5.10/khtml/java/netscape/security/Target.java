package netscape.security;

public class Target {
}