#ifndef _KDEUI_TESTS_KMAINWINDOWRESTORETEST_H_
#define _KDEUI_TESTS_KMAINWINDOWRESTORETEST_H_

#include <kmainwindow.h>

class MainWin1 : public KMainWindow {
  Q_OBJECT
public:
  MainWin1() : KMainWindow() {}
  virtual ~MainWin1() {}
};

class MainWin2 : public KMainWindow {
  Q_OBJECT
public:
  MainWin2() : KMainWindow() {}
  virtual ~MainWin2() {}
};

class MainWin3 : public KMainWindow {
  Q_OBJECT
public:
  MainWin3() : KMainWindow() {}
  virtual ~MainWin3() {}
};

class MainWin4 : public KMainWindow {
  Q_OBJECT
public:
  MainWin4() : KMainWindow() {}
  virtual ~MainWin4() {}
};

class MainWin5 : public KMainWindow {
  Q_OBJECT
public:
  MainWin5() : KMainWindow() {}
  virtual ~MainWin5() {}
};

class MainWin6 : public KMainWindow {
  Q_OBJECT
public:
  MainWin6() : KMainWindow() {}
  virtual ~MainWin6() {}
};

#endif // _KDEUI_TESTS_KMAINWINDOWRESTORETEST_H_
